import boto3
import json
import requests
import os

def handler(event, context):
  messageDetails = event['Records'][0]['Sns']['Message']

  headers = {
    'Content-Type': 'application/json',
  }
  
  data = {"Content": messageDetails }
  url = 'https://hooks.chime.aws/incomingwebhooks/11ae0b7c-8d0a-4ba6-96e3-6581ee6a50d3?token=a0NSZjFUM0t8MXwyNUYzcTRRN05kTlROd3RGN0JOQUQ4ZmZVYVVQOXJMMWVzTU9KOGxCbE9j'
  response = requests.post(url, headers=headers, data=json.dumps(data))
  print(response)


#https://docs.aws.amazon.com/AmazonS3/latest/dev/notification-content-structure.html

